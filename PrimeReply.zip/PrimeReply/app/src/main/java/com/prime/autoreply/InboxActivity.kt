package com.prime.autoreply

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class InboxActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var filterBtn: Button
    private lateinit var list: LinearLayout
    private var filter = ""
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable { override fun run() { refresh(); h.postDelayed(this, 3000) } }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(40), dp(14), dp(8)) }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(TextView(this).apply { text = "📥 সব ইনবক্স"; textSize = 22f; setTextColor(Color.BLACK); typeface = Typeface.DEFAULT_BOLD }, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(Button(this).apply { text = "⚙"; setOnClickListener { startActivity(Intent(this@InboxActivity, MainActivity::class.java)) } })
        root.addView(top)
        status = TextView(this).apply { textSize = 13f; setPadding(0, dp(4), 0, dp(4)) }
        root.addView(status)
        filterBtn = Button(this).apply { text = "সব অ্যাকাউন্ট ▾"; setOnClickListener { pickFilter() } }
        root.addView(filterBtn, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(list) }, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun pickFilter() {
        val all = Inbox.all(this)
        val labels = all.map { it.acct }.distinct()
        val items = arrayOf("সব অ্যাকাউন্ট") + labels.map { l -> "$l (${all.count { it.acct == l && it.unread }} নতুন)" }
        AlertDialog.Builder(this).setTitle("অ্যাকাউন্ট বাছুন").setItems(items) { _, i ->
            filter = if (i == 0) "" else labels[i - 1]
            filterBtn.text = (if (filter.isEmpty()) "সব অ্যাকাউন্ট" else filter) + " ▾"
            refresh()
        }.show()
    }

    private fun timeStr(t: Long): String {
        val now = Calendar.getInstance(); val c = Calendar.getInstance().apply { timeInMillis = t }
        val same = now.get(Calendar.YEAR) == c.get(Calendar.YEAR) && now.get(Calendar.DAY_OF_YEAR) == c.get(Calendar.DAY_OF_YEAR)
        return SimpleDateFormat(if (same) "HH:mm" else "dd/MM", Locale.US).format(Date(t))
    }

    private fun badge(label: String) = TextView(this).apply {
        text = label; textSize = 11f; setTextColor(Color.WHITE); setPadding(dp(8), dp(2), dp(8), dp(2))
        background = GradientDrawable().apply {
            cornerRadius = dp(10).toFloat()
            setColor(Color.HSVToColor(floatArrayOf((Math.abs(label.hashCode()) % 360).toFloat(), 0.6f, 0.7f)))
        }
    }

    private fun refresh() {
        val en = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")?.contains(packageName) == true
        val all = Inbox.all(this)
        val unread = all.count { it.unread }
        status.text = (if (en) "✅ চালু" else "⚠️ নোটিফিকেশন অ্যাক্সেস বন্ধ, ⚙ চেপে চালু করুন") + " • নতুন: $unread • অ্যাকাউন্ট: ${all.map { it.acct }.distinct().size}"
        status.setTextColor(if (en) Color.DKGRAY else Color.RED)
        list.removeAllViews()
        val shown = all.filter { filter.isEmpty() || it.acct == filter }
        if (shown.isEmpty()) {
            list.addView(TextView(this).apply { text = "এখনো কোনো মেসেজ নেই। অ্যাকাউন্টগুলোর নোটিফিকেশন চালু রাখুন, নতুন মেসেজ এলে এখানে দেখা যাবে।"; textSize = 14f; setPadding(0, dp(20), 0, 0) })
            return
        }
        for (cv in shown) list.addView(row(cv), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
    }

    private fun row(cv: Conv): View {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(10), dp(12), dp(10))
            background = GradientDrawable().apply { cornerRadius = dp(12).toFloat(); setColor(if (cv.unread) Color.parseColor("#E8F0FE") else Color.parseColor("#F3F4F6")) }
            setOnClickListener { open(cv) }
        }
        val l1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        l1.addView(badge(cv.acct))
        l1.addView(TextView(this).apply {
            text = "  " + cv.title + (if (cv.group) " 👥" else ""); textSize = 15f; setTextColor(Color.BLACK)
            typeface = if (cv.unread) Typeface.DEFAULT_BOLD else Typeface.DEFAULT; maxLines = 1
        }, LinearLayout.LayoutParams(0, -2, 1f))
        l1.addView(TextView(this).apply { text = (if (cv.unread) "● " else "") + timeStr(cv.ts); textSize = 11f; setTextColor(Color.GRAY) })
        r.addView(l1)
        val last = cv.msgs.lastOrNull()
        r.addView(TextView(this).apply {
            text = (if (last?.me == true) "আপনি: " else "") + (last?.text ?: ""); textSize = 13f; setTextColor(Color.DKGRAY); maxLines = 2; setPadding(0, dp(4), 0, 0)
        })
        return r
    }

    private fun open(cv0: Conv) {
        Inbox.markRead(this, cv0.key)
        val cv = Inbox.get(this, cv0.key) ?: cv0
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(8), dp(18), 0) }
        box.addView(badge(cv.acct))
        box.addView(TextView(this).apply {
            text = cv.msgs.joinToString("\n\n") { (if (it.me) "আপনি" else it.who) + ": " + it.text }
            textSize = 14f; setTextColor(Color.BLACK); setPadding(0, dp(10), 0, dp(10))
        })
        val input = EditText(this).apply { hint = "রিপ্লাই লিখুন..."; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE; minLines = 2; gravity = Gravity.TOP }
        box.addView(input, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        val q = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun quick(t: String, f: () -> String) = q.addView(Button(this).apply {
            text = t; textSize = 12f; minWidth = 0; minimumWidth = 0; setPadding(dp(10), 0, dp(10), 0)
            setOnClickListener { input.setText(f()) }
        }, LinearLayout.LayoutParams(-2, dp(44)))
        quick("🛒 সাইট লিংক") { S.compose(this, cv.title) }
        quick("জি, বলুন") { "জি ভাই, বলুন কোন সার্ভিস লাগবে? 😊" }
        quick("ধন্যবাদ") { "ধন্যবাদ ভাই, আমাদের সাথে থাকার জন্য 😊" }
        box.addView(HorizontalScrollView(this).apply { addView(q) })

        val d = AlertDialog.Builder(this).setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("পাঠান", null).setNeutralButton("অ্যাপে খুলুন", null).setNegativeButton("বন্ধ", null).create()
        d.show()
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val t = input.text.toString().trim()
            if (t.isEmpty()) { Toast.makeText(this, "আগে মেসেজ লিখুন", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            val err = Inbox.send(this, cv.key, t)
            if (err == null) { Toast.makeText(this, "✅ পাঠানো হয়েছে", Toast.LENGTH_SHORT).show(); d.dismiss(); refresh() }
            else Toast.makeText(this, err, Toast.LENGTH_LONG).show()
        }
        d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
            if (!Inbox.openChat(cv.key)) Toast.makeText(this, "এই চ্যাট এখন খোলা যাচ্ছে না, অ্যাপ নিজে খুলুন", Toast.LENGTH_LONG).show()
        }
        refresh()
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }
}
