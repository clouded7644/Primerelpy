package com.prime.autoreply

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var logBox: LinearLayout
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable { override fun run() { refresh(); h.postDelayed(this, 4000) } }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val mw = ViewGroup.LayoutParams.MATCH_PARENT
        val wc = ViewGroup.LayoutParams.WRAP_CONTENT
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }
        fun tv(s: String, size: Float = 14f) = TextView(this).apply { text = s; textSize = size; setPadding(0, pad / 2, 0, pad / 4) }
        fun et(hint: String, v: String, type: Int = InputType.TYPE_CLASS_TEXT, lines: Int = 1) = EditText(this).apply {
            this.hint = hint; setText(v); inputType = type
            if (lines > 1) { inputType = type or InputType.TYPE_TEXT_FLAG_MULTI_LINE; minLines = lines; gravity = Gravity.TOP }
        }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }

        val sp = S.sp(this)
        root.addView(tv("⚙ Prime Inbox সেটিংস", 22f))
        status = tv("", 15f)
        root.addView(status)

        val on = CheckBox(this).apply { text = "চালু আছে (অটো রিপ্লাই হবে)"; isChecked = S.on(this@MainActivity) }
        root.addView(on)

        root.addView(tv("কোন অ্যাকাউন্টে অটো রিপ্লাই চলবে (মেসেজ আসলে অ্যাকাউন্টগুলো এখানে নিজে যোগ হয়)"))
        val seen = S.seenAccts(this)
        if (seen.isEmpty()) root.addView(tv("এখনো কোনো অ্যাকাউন্ট ধরা পড়েনি। প্রতিটা অ্যাকাউন্টে একটা মেসেজ এলে এখানে দেখা যাবে।", 13f))
        val appBoxes = seen.map { (pkg, name) -> pkg to CheckBox(this).apply { text = name; isChecked = S.autoOn(this@MainActivity, pkg) } }
        appBoxes.forEach { root.addView(it.second) }

        root.addView(tv("দোকানের নাম"))
        val shop = et("Prime Digital Shop", S.shop(this))
        root.addView(shop, mw, wc)
        root.addView(tv("সাইট লিংক"))
        val url = et("https://...", S.url(this), InputType.TYPE_TEXT_VARIATION_URI)
        root.addView(url, mw, wc)

        root.addView(tv("রিপ্লাই মেসেজ (একাধিক ভার্সন আলাদা করতে মাঝে একটা লাইনে --- লিখুন; প্রতিবার র‍্যান্ডম একটা যাবে। {name} {shop} {url} বসবে)", 13f))
        val msgs = et("মেসেজ", S.msgs(this), InputType.TYPE_CLASS_TEXT, 12)
        root.addView(msgs, mw, wc)

        root.addView(tv("একই ব্যক্তিকে আবার রিপ্লাই দেওয়ার আগে কত ঘণ্টা অপেক্ষা"))
        val cool = et("12", S.cooldownH(this).toString(), InputType.TYPE_CLASS_NUMBER)
        root.addView(cool, mw, wc)
        root.addView(tv("ঘণ্টায় সর্বোচ্চ কতজনকে রিপ্লাই"))
        val maxh = et("30", S.maxHour(this).toString(), InputType.TYPE_CLASS_NUMBER)
        root.addView(maxh, mw, wc)
        root.addView(tv("রিপ্লাই দিতে সর্বোচ্চ কত সেকেন্ড দেরি (২–৬০, র‍্যান্ডম)"))
        val delay = et("6", S.delaySec(this).toString(), InputType.TYPE_CLASS_NUMBER)
        root.addView(delay, mw, wc)
        root.addView(tv("শুধু এই শব্দ থাকলে রিপ্লাই (কমা দিয়ে, খালি মানে সবাইকে)", 13f))
        val kw = et("rate,price,দাম,ফলোয়ার", sp.getString("kw", "") ?: "")
        root.addView(kw, mw, wc)
        root.addView(tv("এই নামের কাউকে রিপ্লাই দেবে না (কমা দিয়ে, যেমন পরিবার/বন্ধু)", 13f))
        val ign = et("মা, আব্বু, ভাইয়া", sp.getString("ign", "") ?: "")
        root.addView(ign, mw, wc)

        fun save() {
            val e = sp.edit().putBoolean("on", on.isChecked)
                .putString("shop", shop.text.toString().trim()).putString("url", url.text.toString().trim())
                .putString("msgs", msgs.text.toString().trim())
                .putString("cool", cool.text.toString().trim()).putString("maxh", maxh.text.toString().trim())
                .putString("delay", delay.text.toString().trim())
                .putString("kw", kw.text.toString().trim()).putString("ign", ign.text.toString().trim())
            appBoxes.forEach { (pkg, box) -> e.putBoolean("auto_$pkg", box.isChecked) }
            e.apply()
        }

        root.addView(btn("💾 সেভ করুন") { save(); Toast.makeText(this, "সেভ হয়েছে", Toast.LENGTH_SHORT).show(); refresh() })
        root.addView(btn("👁 মেসেজ প্রিভিউ") {
            save()
            AlertDialog.Builder(this).setTitle("প্রিভিউ").setMessage(S.compose(this, "রহিম")).setPositiveButton("ঠিক আছে", null).show()
        })
        root.addView(btn("🔔 নোটিফিকেশন অ্যাক্সেস দিন") { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) })
        root.addView(btn("🔋 ব্যাটারি অপ্টিমাইজেশন বন্ধ করুন") {
            try { startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))) }
            catch (e: Exception) { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        })

        root.addView(tv("সাম্প্রতিক রিপ্লাই", 16f))
        logBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(logBox, mw, wc)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun refresh() {
        val en = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")?.contains(packageName) == true
        status.text = (if (en) "✅ নোটিফিকেশন অ্যাক্সেস চালু" else "⚠️ নোটিফিকেশন অ্যাক্সেস বন্ধ (নিচের বাটন চেপে চালু করুন)") +
            "\nগত ১ ঘণ্টায় রিপ্লাই: ${S.countHour(this)}"
        logBox.removeAllViews()
        for (l in S.logs(this)) logBox.addView(TextView(this).apply { text = l; textSize = 12f; setPadding(0, 8, 0, 8) })
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }
}
