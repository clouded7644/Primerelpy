package com.prime.autoreply

import android.app.Notification
import android.app.RemoteInput
import android.content.ComponentName
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class ReplyService : NotificationListenerService() {
    private val ui = Handler(Looper.getMainLooper())
    private val seen = LinkedHashSet<String>()

    override fun onListenerDisconnected() {
        try { requestRebind(ComponentName(this, ReplyService::class.java)) } catch (_: Exception) {}
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try { handle(sbn) } catch (_: Exception) {}
    }

    private fun label(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (_: Exception) { S.APPS[pkg] ?: pkg }

    private fun handle(sbn: StatusBarNotification) {
        val c = applicationContext
        val pkg = sbn.packageName
        if (pkg == packageName) return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val ex = n.extras

        // রিপ্লাই অ্যাকশন
        var chosen: Notification.Action? = null
        var rin: RemoteInput? = null
        for (a in n.actions ?: emptyArray()) {
            val r = a.remoteInputs?.firstOrNull { it.allowFreeFormInput } ?: continue
            val isReply = Build.VERSION.SDK_INT >= 28 && a.semanticAction == Notification.Action.SEMANTIC_ACTION_REPLY
            if (chosen == null || isReply) { chosen = a; rin = r }
            if (isReply) break
        }
        val known = S.isKnown(pkg) || n.category == Notification.CATEGORY_MESSAGE
        if (!known && chosen == null) return

        val title0 = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim() ?: return
        val text = (ex.getCharSequence(Notification.EXTRA_TEXT) ?: ex.getCharSequence(Notification.EXTRA_BIG_TEXT))?.toString()?.trim() ?: return
        if (title0.isEmpty() || text.isEmpty()) return
        if (title0.equals("WhatsApp", true) || title0.equals("Messenger", true) || title0.equals("WhatsApp Business", true)) return
        if (Regex("\\d+\\s+(new\\s+)?messages?", RegexOption.IGNORE_CASE).containsMatchIn(text) && text.lowercase().contains("chat")) return

        val convTitle = ex.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)?.toString()?.trim() ?: ""
        val group = (Build.VERSION.SDK_INT >= 28 && ex.getBoolean(Notification.EXTRA_IS_GROUP_CONVERSATION)) ||
            (pkg.startsWith("com.whatsapp") && convTitle.isNotEmpty())
        val title = if (group && convTitle.isNotEmpty()) convTitle else title0

        val acct = label(pkg)
        S.noteAcct(c, pkg, acct)
        val key = pkg + "|" + sbn.user.hashCode() + "|" + title.lowercase()

        // মেসেজগুলো সংগ্রহ
        val msgs = mutableListOf<Msg>()
        val arr = ex.getParcelableArray(Notification.EXTRA_MESSAGES)
        if (arr != null) for (p in arr) {
            if (p is Bundle) {
                val t = p.getCharSequence("text")?.toString()
                if (!t.isNullOrBlank()) msgs.add(Msg(p.getCharSequence("sender")?.toString()?.ifEmpty { null } ?: title0, t, p.getLong("time"), false))
            }
        }
        if (msgs.isEmpty()) msgs.add(Msg(title0, text, sbn.postTime, false))

        val act = chosen
        val ri = rin
        if (act != null && ri != null) Inbox.handles[key] = Inbox.Handle(act.actionIntent, ri, n.contentIntent)

        val dk = sbn.key + "|" + sbn.postTime
        if (!seen.add(dk)) return
        while (seen.size > 160) seen.remove(seen.first())
        Inbox.add(c, key, pkg, acct, title, group, msgs)

        // ---------- অটো রিপ্লাই ----------
        if (!S.on(c) || !S.autoOn(c, pkg) || group) return
        if (act == null || ri == null) return
        val lt = title.lowercase()
        if (S.ignore(c).any { lt.contains(it) }) return
        val kws = S.keywords(c)
        if (kws.isNotEmpty() && kws.none { text.lowercase().contains(it) }) return
        val now = System.currentTimeMillis()
        if (now - S.last(c, key) < S.cooldownH(c) * 3600000L) return
        if (S.countHour(c) >= S.maxHour(c)) { S.log(c, "⏸ $acct • $title → ঘণ্টার সীমা শেষ"); return }

        S.setLast(c, key)
        val msg = S.compose(c, title)
        val d = ((2000..(S.delaySec(c) * 1000)).random()).toLong()
        ui.postDelayed({
            val err = Inbox.send(c, key, msg)
            if (err == null) { S.recordUse(c); S.log(c, "✅ $acct • $title → অটো রিপ্লাই গেছে") }
            else S.log(c, "❌ $acct • $title → $err")
        }, d)
    }
}
