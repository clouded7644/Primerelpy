package com.prime.autoreply

import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Bundle
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object S {
    const val DEFAULT_URL = "https://prime-digital-shop.pages.dev/"
    const val DEFAULT_SHOP = "Prime Digital Shop"

    val APPS = linkedMapOf(
        "com.whatsapp" to "WhatsApp",
        "com.whatsapp.w4b" to "WhatsApp Business",
        "com.facebook.orca" to "Messenger",
        "com.facebook.mlite" to "Messenger Lite",
        "com.instagram.android" to "Instagram",
        "org.telegram.messenger" to "Telegram"
    )
    fun isKnown(pkg: String) = APPS.containsKey(pkg) || pkg.startsWith("com.facebook") || pkg.startsWith("com.whatsapp")

    val DEFAULT_MSG = """আসসালামু আলাইকুম {name} 👋
{shop}-এ স্বাগতম! 🚀

✅ ফলোয়ার, লাইক, ভিউ ও সব সোশ্যাল মিডিয়া সার্ভিস
✅ সবচেয়ে কম দাম, দ্রুত ডেলিভারি
✅ bKash / Nagad / Rocket-এ নিরাপদ পেমেন্ট

🛒 অর্ডার করুন:
{url}

কোনো প্রশ্ন থাকলে এখানেই লিখুন, সাহায্য করবো 😊
---
হ্যালো {name} 😊
আমাদের সাইটে Facebook, Instagram, TikTok, YouTube, Telegram-এর সব সার্ভিস পাবেন, কম দামে আর দ্রুত ডেলিভারিতে।

👉 {url}

সাইটে রেট দেখে সরাসরি অর্ডার করতে পারেন। সাহায্য লাগলে জানান।
---
আসসালামু আলাইকুম {name} 🌟
{shop} থেকে মেসেজ করার জন্য ধন্যবাদ।

📌 সব সার্ভিস ও রেট একসাথে দেখুন:
{url}

অর্ডারের পর পেমেন্টের TrxID দিলেই অটো ভেরিফাই হয়ে যায় ⚡"""

    fun sp(c: Context) = c.getSharedPreferences("ar", Context.MODE_PRIVATE)
    fun on(c: Context) = sp(c).getBoolean("on", true)
    fun autoOn(c: Context, pkg: String) = sp(c).getBoolean("auto_$pkg", isKnown(pkg))
    fun seenAccts(c: Context): Map<String, String> = try {
        val j = JSONObject(sp(c).getString("seen", "{}")); j.keys().asSequence().associateWith { j.optString(it) }
    } catch (_: Exception) { emptyMap() }
    fun noteAcct(c: Context, pkg: String, label: String) {
        val j = try { JSONObject(sp(c).getString("seen", "{}")) } catch (_: Exception) { JSONObject() }
        if (j.optString(pkg) != label) { j.put(pkg, label); sp(c).edit().putString("seen", j.toString()).apply() }
    }
    fun shop(c: Context) = sp(c).getString("shop", DEFAULT_SHOP) ?: DEFAULT_SHOP
    fun url(c: Context) = sp(c).getString("url", DEFAULT_URL) ?: DEFAULT_URL
    fun msgs(c: Context) = sp(c).getString("msgs", DEFAULT_MSG) ?: DEFAULT_MSG
    fun cooldownH(c: Context) = (sp(c).getString("cool", "12") ?: "12").toIntOrNull() ?: 12
    fun maxHour(c: Context) = (sp(c).getString("maxh", "30") ?: "30").toIntOrNull() ?: 30
    fun delaySec(c: Context) = ((sp(c).getString("delay", "6") ?: "6").toIntOrNull() ?: 6).coerceIn(2, 60)
    fun keywords(c: Context) = (sp(c).getString("kw", "") ?: "").split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }
    fun ignore(c: Context) = (sp(c).getString("ign", "") ?: "").split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }

    fun splitVariants(s: String) = s.split(Regex("\\n\\s*---\\s*\\n")).map { it.trim() }.filter { it.isNotEmpty() }

    fun compose(c: Context, title: String): String {
        val list = splitVariants(msgs(c)).ifEmpty { splitVariants(DEFAULT_MSG) }
        val first = title.trim().split(Regex("\\s+")).firstOrNull() ?: ""
        val name = if (first.isEmpty() || Regex("^[+\\d\\-()]+\$").matches(first) || first.length > 20) "" else first
        return list.random()
            .replace("{name}", name).replace("{shop}", shop(c)).replace("{url}", url(c))
            .replace(Regex("[ \\t]{2,}"), " ").replace(" \n", "\n").trim()
    }

    // ---- cooldown per contact ----
    fun last(c: Context, key: String): Long = try { JSONObject(sp(c).getString("last", "{}")).optLong(key, 0L) } catch (_: Exception) { 0L }

    fun setLast(c: Context, key: String) {
        val j = try { JSONObject(sp(c).getString("last", "{}")) } catch (_: Exception) { JSONObject() }
        val now = System.currentTimeMillis()
        j.put(key, now)
        if (j.length() > 300) {
            val it = j.keys().asSequence().toList()
            for (k in it) if (now - j.optLong(k) > 7L * 24 * 3600 * 1000) j.remove(k)
        }
        sp(c).edit().putString("last", j.toString()).apply()
    }

    // ---- hourly cap ----
    private fun uses(c: Context): MutableList<Long> {
        val now = System.currentTimeMillis()
        val out = mutableListOf<Long>()
        try {
            val a = JSONArray(sp(c).getString("uses", "[]"))
            for (i in 0 until a.length()) { val t = a.getLong(i); if (now - t < 3600000L) out.add(t) }
        } catch (_: Exception) {}
        return out
    }
    fun countHour(c: Context) = uses(c).size
    fun recordUse(c: Context) {
        val l = uses(c); l.add(System.currentTimeMillis())
        sp(c).edit().putString("uses", JSONArray(l).toString()).apply()
    }

    // ---- log ----
    fun log(c: Context, line: String) {
        val f = SimpleDateFormat("dd/MM HH:mm", Locale.US).format(Date())
        val l = logs(c).toMutableList()
        l.add(0, "$f  $line")
        while (l.size > 40) l.removeAt(l.size - 1)
        sp(c).edit().putString("log", JSONArray(l).toString()).apply()
    }
    fun logs(c: Context): List<String> = try {
        val a = JSONArray(sp(c).getString("log", "[]")); (0 until a.length()).map { a.getString(it) }
    } catch (_: Exception) { emptyList() }
}


class Msg(val who: String, val text: String, val ts: Long, val me: Boolean)
class Conv(val key: String, val pkg: String, val acct: String, val title: String, var ts: Long, var unread: Boolean, var group: Boolean, val msgs: MutableList<Msg>)

object Inbox {
    private val lock = Any()
    class Handle(val send: PendingIntent, val ri: RemoteInput, val content: PendingIntent?)
    val handles = java.util.concurrent.ConcurrentHashMap<String, Handle>()

    private fun load(c: Context): MutableList<Conv> {
        val out = mutableListOf<Conv>()
        try {
            val a = JSONArray(S.sp(c).getString("inbox", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val ms = mutableListOf<Msg>()
                val ma = o.optJSONArray("m")
                if (ma != null) for (j in 0 until ma.length()) {
                    val m = ma.getJSONObject(j)
                    ms.add(Msg(m.optString("w"), m.optString("t"), m.optLong("s"), m.optBoolean("me")))
                }
                out.add(Conv(o.getString("k"), o.optString("p"), o.optString("a"), o.optString("ti"), o.optLong("ts"), o.optBoolean("u"), o.optBoolean("g"), ms))
            }
        } catch (_: Exception) {}
        return out
    }

    private fun save(c: Context, l: List<Conv>) {
        val a = JSONArray()
        for (cv in l) {
            val ma = JSONArray()
            for (m in cv.msgs) ma.put(JSONObject().put("w", m.who).put("t", m.text).put("s", m.ts).put("me", m.me))
            a.put(JSONObject().put("k", cv.key).put("p", cv.pkg).put("a", cv.acct).put("ti", cv.title).put("ts", cv.ts).put("u", cv.unread).put("g", cv.group).put("m", ma))
        }
        S.sp(c).edit().putString("inbox", a.toString()).apply()
    }

    fun all(c: Context): List<Conv> = synchronized(lock) { load(c).sortedByDescending { it.ts } }
    fun get(c: Context, key: String): Conv? = synchronized(lock) { load(c).firstOrNull { it.key == key } }

    fun add(c: Context, key: String, pkg: String, acct: String, title: String, group: Boolean, incoming: List<Msg>) {
        synchronized(lock) {
            val l = load(c)
            var cv = l.firstOrNull { it.key == key }
            if (cv == null) { cv = Conv(key, pkg, acct, title, 0L, false, group, mutableListOf()); l.add(cv) }
            var added = false
            for (m in incoming) {
                if (cv.msgs.takeLast(3).none { it.text == m.text && it.me == m.me }) { cv.msgs.add(m); added = true }
            }
            while (cv.msgs.size > 8) cv.msgs.removeAt(0)
            if (added) { cv.ts = System.currentTimeMillis(); cv.unread = true }
            l.sortByDescending { it.ts }
            while (l.size > 150) l.removeAt(l.size - 1)
            save(c, l)
        }
    }

    fun addMine(c: Context, key: String, text: String) {
        synchronized(lock) {
            val l = load(c)
            val cv = l.firstOrNull { it.key == key } ?: return
            cv.msgs.add(Msg("আপনি", text, System.currentTimeMillis(), true))
            while (cv.msgs.size > 8) cv.msgs.removeAt(0)
            cv.ts = System.currentTimeMillis(); cv.unread = false
            save(c, l)
        }
    }

    fun markRead(c: Context, key: String) {
        synchronized(lock) {
            val l = load(c)
            l.firstOrNull { it.key == key }?.unread = false
            save(c, l)
        }
    }

    fun clear(c: Context) { synchronized(lock) { save(c, emptyList()) } }

    /** null মানে সফল, নইলে এরর মেসেজ */
    fun send(c: Context, key: String, text: String): String? {
        val h = handles[key] ?: return "এই চ্যাটের রিপ্লাই অপশন এখন নেই। নতুন মেসেজ এলে আবার পাবেন, অথবা \"অ্যাপে খুলুন\" চাপুন।"
        return try {
            val i = Intent()
            val b = Bundle()
            b.putCharSequence(h.ri.resultKey, text)
            RemoteInput.addResultsToIntent(arrayOf(h.ri), i, b)
            h.send.send(c, 0, i)
            addMine(c, key, text)
            S.setLast(c, key)
            null
        } catch (e: Exception) { e.message ?: "পাঠানো যায়নি" }
    }

    fun openChat(key: String): Boolean = try { handles[key]?.content?.send(); handles[key]?.content != null } catch (_: Exception) { false }
}
